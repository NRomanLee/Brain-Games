def greet(greet_speech):
    print(greet_speech)
def main():
    greet("Welcome to the Brain Games!")

if __name__ == "__main__":
    main()
    import welcome_user
    
