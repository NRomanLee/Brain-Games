### Hexlet tests and linter status:
[![Actions Status](https://github.com/NRomanLee/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/NRomanLee/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/78c0a76e4cc7c9dd7f3a/maintainability)](https://codeclimate.com/github/NRomanLee/python-project-49/maintainability)
